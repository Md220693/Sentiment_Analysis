#!/usr/bin/env python
# coding: utf-8

# In[1]:



# Import Liabraries:
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import TensorDataset, DataLoader
import urllib


# # Sentiment analysis
# 
# The file *IMD.txt* contains reviews by users about movies, organized by line (each line in the file is a different review). In the *labelled.txt*, for each review we have a label (positive/negative).
# 
# We want to find out if the review is positive or negative.
# Let's try to train a rnn for reviews classification.
# 

# ## Preparing the datasets
# First of all, we have to prepare our datasets.

# In[73]:


size_of_dataset = 10000


# ### Reading the files and converting them into Tensors

# In[2]:


# Load reviews to string
IMDB_reviews_path = "IMD.txt"
with open(IMDB_reviews_path, encoding='utf8') as f:
    IMDB_reviews = f.read()


# In[3]:


type(IMDB_reviews)


# In[4]:


len(IMDB_reviews)


# Now, we have to remove all puntuaction simbols inside the sentences. 

# In[6]:


# Remove punctuaction
from string import punctuation
punctuation


# In[7]:


list_characters = [c for c in IMDB_reviews if c not in punctuation]


# In[8]:


len(IMDB_reviews) - len(list_characters)


# In[9]:


IMDB_reviews = "".join(list_characters)


# In[10]:


IMDB_reviews[:1000]


# In[11]:


# split the reviews
IMDB_reviews = IMDB_reviews.split("\n")


# now `reviews` is a list of sentences:

# In[12]:


# each element of reviews is a review
IMDB_reviews[0]
IMDB_reviews = IMDB_reviews[:size_of_dataset]


# In[13]:


len(IMDB_reviews)


# In[14]:


print(IMDB_reviews[9])


# In[15]:


#last elem in reviews list is an empty string, so discard it
#print(IMDB_reviews[40000])
#IMDB_reviews = IMDB_reviews[:-1]


# Since the input of our model will be the individual word, now we have to split the words inside the sentence

# In[16]:


IMDB_reviews = [[w for w in r.split(" ") if len(w)>0] for r in IMDB_reviews]


# now `reviews` is a list of list. Each reaview is a list of words.

# In[17]:


IMDB_reviews[0]


# In[18]:


# compute the length of each review
IMDB_reviews_lens = [len(r) for r in IMDB_reviews]
# print the lenght of the first x reviews


# In[19]:


# print the average review lenght
sum(IMDB_reviews_lens) / len(IMDB_reviews_lens)


# Our rnn cannot use words directly, we have to convert each word in a number. When we pass a review to the model, the model will see a sequence of numbers.
# To do this, let's create the vocabulary of our words.

# In[20]:


# build vocabulary
words = list(set([w for r in IMDB_reviews for w in r]))
vocab = {words[i]: i+1 for i in range(len(words))} # we reserve i=0 for pad sequences


# In[21]:


len(vocab)


# In[22]:


vocab


# In[23]:


# Convert reviews to word indexes
IMDB_reviews = [[vocab[w] for w in r] for r in IMDB_reviews]


# In[24]:


IMDB_reviews[0]


# In[25]:


words[9-1]


# The reviews have different lengths, while, we want that all reviews have the same length
# 

# In[26]:


seq_len = 200    # number of words for each sentence


# In[27]:


# Clip reviews to max seq_len words
IMDB_reviews = [r[:seq_len] for r in IMDB_reviews]


# In[28]:


# Print average review length now
IMDB_review_lens = [len(r) for r in IMDB_reviews]
print(sum(IMDB_review_lens)/len(IMDB_review_lens))


# In[29]:


# Pad reviews shorter than seq_len
# TODO test padding at the end
IMDB_reviews = [[0]*(seq_len - len(r)) + r for r in IMDB_reviews]


# In[30]:


# Print average review length now
IMDB_review_lens = [len(r) for r in IMDB_reviews]
print(sum(IMDB_review_lens)/len(IMDB_review_lens))


# Now, `reviews` is a list of list; each elem of `reviews` is a list with `seq_len` elements. So we can convert `reviews` in a Tensor:
# 

# In[31]:


# Convert reviews to tensor
data = torch.LongTensor(IMDB_reviews)


# In[32]:


data.size()


# Finally the data tensor is ready. Now it's the turn of the labels.
# 

# In[33]:


# Load labels to string
sentiments_path = "labelled.txt"
with open(sentiments_path, encoding="utf8") as f:
    sentiments = f.read()


# In[34]:


sentiments


# In[35]:


sentiments = sentiments.split("\n")


# In[36]:


sentiments = sentiments[:size_of_dataset]
len(sentiments)


# In[37]:


# discard the last elem of sentiments (empty string)
#sentiments = sentiments[:-1]


# In[38]:


sentiments = [0 if sentiments[i]=='negative' else 1 for i in range(len(sentiments))]


# In[39]:


# Convert sentiments to tensor
labels = torch.LongTensor(sentiments)


# In[40]:


labels.size()


# ### Defining the Datasets

# In[41]:


# some parameters
frac_train = 0.6 # fraction of data for train
frac_val = 0.3   # fraction of data for val
batch_size = 64


# In[42]:


# shuffle dataset
num_data = data.size(0)
shuffle_idx = torch.randperm(num_data)
data = data[shuffle_idx,:]
labels = labels[shuffle_idx]


# In[43]:


# split training, validation and test
num_train = int(num_data*frac_train)
num_val = int(num_data*frac_val)
num_test = num_data - num_train - num_val
train_data = data[:num_train,:]
train_labels = labels[:num_train]
val_data = data[num_train:num_train+num_val,:]
val_labels = labels[num_train:num_train+num_val]
test_data = data[num_train+num_val:,:]
test_labels = labels[num_train+num_val:]


# In[44]:


print(train_data.size())
print(val_data.size())
print(test_data.size())


# In[45]:


# create datasets
train_dataset = TensorDataset(train_data, train_labels)
val_dataset = TensorDataset(val_data, val_labels)
test_dataset = TensorDataset(test_data, test_labels)


# In[46]:


# print the first elem of train dataset and its label
print(train_dataset[0])


# In[47]:


# Create loaders
loaders = {"train": DataLoader(train_dataset, batch_size=batch_size, shuffle=True,  drop_last=True),
           "val":   DataLoader(val_dataset,   batch_size=batch_size, shuffle=False, drop_last=False),
           "test":  DataLoader(test_dataset,  batch_size=batch_size, shuffle=False, drop_last=False)}


# ## Defining our RNN

# The [torch.nn.Embedding](https://pytorch.org/docs/stable/generated/torch.nn.Embedding.html) module:
# 
# Basically, the Embedding module translates numbers in vectors. The *translation function* is learned by this module during the training. 

# In[48]:


#####
#  torch.nn.Embedding(num_embeddings: int, embedding_dim: int)
#  where:
#   - num_embeddings: int, is the number of inputs (size of our input vocabulary)
#   - embedding_dim: int  is the size of each feature vector (size of the output vector)
#####
test_embedding = nn.Embedding(5, 10)


# In[49]:


# example input to embedding: a batch with 2 elements, each elem has length 3
input = torch.LongTensor([[3, 2, 1],[2, 3, 1]])
input.shape


# In[50]:


# Print embedding size
output = test_embedding(input)


# In[51]:


output 


# In[52]:


output.shape


# In[53]:


# Define model
class Model(nn.Module):
    
    def __init__(self, num_embed, embed_size, rnn_size):
        # params: 
        # num_embed: the number of the input vocabulary
        # embed_size: the size of the feature embedding
        # rnn_size: the number of neurons in the recurrent layer

        # Call parent constructor
        super().__init__()
        # Store values
        self.rnn_size = rnn_size
        # Define modules
        self.embedding = nn.Embedding(len(vocab)+1, embed_size)
        self.rnn = nn.RNNCell(embed_size, rnn_size) #RNNCell represents only a single time step
        self.output = nn.Linear(rnn_size, 2)
        
    def forward(self, x):
        # Embed data
        x = self.embedding(x)
        # Initialize state
        h = torch.zeros(x.shape[0], self.rnn_size).to(x.device.type) # the state of the cell
        
        # Input is: B x T x F
        # Process each time step
        for t in range(x.shape[1]):
            # Input at time t
            x_t = x[:,t,:]
            # Forward RNN and get new state
            h = self.rnn(x_t, h)
        # Classify final state
        x = self.output(h)
        return x


# In[54]:


# Setup device
dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# In[55]:


# Model parameters
embed_size = 1024
rnn_size = 256


# In[56]:


# Create model
model = Model(len(vocab)+1, embed_size, rnn_size).to(dev)


# In[57]:


# Test model output
model.eval()
test_input = train_dataset[0][0].unsqueeze(0).to(dev)
print("Model output size:", model(test_input).size())


# In[58]:


# Create optimizer
optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=5e-4)

# Define a loss 
criterion = nn.CrossEntropyLoss()


# In[59]:


# Start training
import torch
import torchvision.models as models
from tqdm import tqdm
best_accuracy= 0.00
for epoch in range(20):
    # Initialize accumulators for computing average loss/accuracy
    epoch_loss_sum = {'train': 0, 'val': 0, 'test': 0}
    epoch_loss_cnt = {'train': 0, 'val': 0, 'test': 0}
    epoch_accuracy_sum = {'train': 0, 'val': 0, 'test': 0}
    epoch_accuracy_cnt = {'train': 0, 'val': 0, 'test': 0}
    # Process each split
    for split in ["train", "val", "test"]:
        # Set network mode
        if split == "train":
            model.train()
            torch.set_grad_enabled(True)
        else:
            model.eval()
            torch.set_grad_enabled(False)
        # Process all data in split
        for input, target in tqdm(loaders[split]):
            # Move to device
            input = input.to(dev)
            target = target.to(dev)
            # Reset gradients
            optimizer.zero_grad()
            # Forward
            output = model(input)
            loss = criterion(output, target)
            # Update loss sum
            epoch_loss_sum[split] += loss.item()
            epoch_loss_cnt[split] += 1
            # Compute accuracy
            _,pred = output.max(1)
            correct = pred.eq(target).sum().item()
            accuracy = correct/input.size(0)
            # Update accuracy sum
            epoch_accuracy_sum[split] += accuracy
            epoch_accuracy_cnt[split] += 1
            # Backward and optimize
            if split == "train":
                loss.backward()
                optimizer.step()
    # Compute average epoch loss/accuracy
    print("epoch loss is ")
    print(epoch_loss_cnt["train"])
    avg_train_loss = epoch_loss_sum["train"]/epoch_loss_cnt["train"]
    avg_train_accuracy = epoch_accuracy_sum["train"]/epoch_accuracy_cnt["train"]
    avg_val_loss = epoch_loss_sum["val"]/epoch_loss_cnt["val"]
    avg_val_accuracy = epoch_accuracy_sum["val"]/epoch_accuracy_cnt["val"]
    avg_test_loss = epoch_loss_sum["test"]/epoch_loss_cnt["test"]
    avg_test_accuracy = epoch_accuracy_sum["test"]/epoch_accuracy_cnt["test"]
    print(f"Epoch: {epoch+1}, TrL={avg_train_loss:.4f}, TrA={avg_train_accuracy:.4f},",
                            f"VL={avg_val_loss:.4f}, VA={avg_val_accuracy:.4f}, ",
                            f"TeL={avg_test_loss:.4f}, TeA={avg_test_accuracy:.4f}")
    
   # saving the model:
    #if avg_test_accuracy>best_accuracy:
        #torch.save(model.state_dict(),'best_checkpoint.model')
       # best_accuracy=avg_test_accuracy


# In[60]:


torch.save(model.state_dict(),'best_checkpoint.model')


# In[61]:


vocab


# In[62]:


output


# In[63]:


test_labels


# In[246]:


pip install tensorflow


# In[66]:


# Test review
import tensorflow as tf
#checkpoint=torch.load('best_checkpoint.model')
#model = Model(len(vocab)+1, embed_size, rnn_size,).to(dev)
#model.load_state_dict(checkpoint)
model.eval()
review = "i really liked this movie it is great done"
#review = "i didn t like this move"
#review = "that movie is a complete waste of time and resources"
#review = "honestly i preferred the previous movie of that saga"
review = [vocab[w] for w in review.split(" ")]
review = [0]*(seq_len - len(review)) + review
review = torch.LongTensor(review).unsqueeze(0).to(dev)
# Process review
model.eval()
output = model(test_data).cpu()
probabilities = F.softmax(output,1)
_,pred = output.max(1)


res = tf.math.confusion_matrix(test_labels,pred)


# In[70]:


print('Confusion_matrix: ',res)

